package com.unity3d.ads.test;

import com.unity3d.scar.adapter.v1950.signals.SignalsReaderTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	SignalsReaderTest.class
})
public class InstrumentationTestSuite {
}
