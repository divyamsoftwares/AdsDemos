package com.unity3d.ads.test;

import com.unity3d.ads.test.environment.*;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
		EnvironmentTest.class
})
public class EnvironmentTestSuite {}
