package com.unity3d.ads.test.legacy;

import android.app.Activity;

public class TestActivity extends Activity {

	public TestActivity() {
		super();
	}
}
