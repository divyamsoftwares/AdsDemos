package com.unity3d.ads.test.legacy;

import android.app.Activity;

public class LifecycleListenerTestBaseActivity extends Activity {

}
