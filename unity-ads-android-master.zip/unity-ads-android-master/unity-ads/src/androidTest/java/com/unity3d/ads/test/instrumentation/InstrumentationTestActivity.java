package com.unity3d.ads.test.instrumentation;

import android.app.Activity;
import android.os.Bundle;


public class InstrumentationTestActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}
