package com.unity3d.services.purchasing.core.webview;

public enum WebViewEventCategory {
    CUSTOM_PURCHASING
}
