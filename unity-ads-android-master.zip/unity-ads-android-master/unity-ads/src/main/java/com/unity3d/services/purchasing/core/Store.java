package com.unity3d.services.purchasing.core;

public enum Store {
    NOT_SPECIFIED,
    GOOGLE_PLAY,
    AMAZON_APP_STORE,
    CLOUD_MOOLAH,
    SAMSUNG_APPS,
    XIAOMI_MI_PAY,
    MAC_APP_STORE,
    APPLE_APP_STORE,
    WIN_RT,
    TIZEN_STORE,
    FACEBOOK_STORE
}
