package com.unity3d.services.core.request;

public enum SDKMetricEvents {
	native_load_callback_error,
	native_load_callback_timeout,
	native_show_callback_error,
	native_show_callback_timeout,
	native_load_timeout_error,
	native_show_timeout_error
}
