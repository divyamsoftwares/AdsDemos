package com.unity3d.services.core.connectivity;

public interface IConnectivityListener {
	public void onConnected();
	public void onDisconnected();
}