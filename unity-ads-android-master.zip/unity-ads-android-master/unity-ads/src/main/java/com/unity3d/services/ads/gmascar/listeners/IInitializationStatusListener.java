package com.unity3d.services.ads.gmascar.listeners;

public interface IInitializationStatusListener {
	void onInitializationComplete(Object initStatus);
}
