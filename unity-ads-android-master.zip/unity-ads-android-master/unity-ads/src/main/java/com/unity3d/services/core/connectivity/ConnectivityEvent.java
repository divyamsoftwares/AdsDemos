package com.unity3d.services.core.connectivity;

public enum ConnectivityEvent {
	CONNECTED, DISCONNECTED, NETWORK_CHANGE
}