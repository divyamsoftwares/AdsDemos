package com.unity3d.services.core.request;

public class NetworkIOException extends Exception {
	public NetworkIOException (String message) {
		super(message);
	}
}
