package com.unity3d.services.core.sensorinfo;

public enum SensorInfoError {
	ACCELEROMETER_DATA_NOT_AVAILABLE
}
