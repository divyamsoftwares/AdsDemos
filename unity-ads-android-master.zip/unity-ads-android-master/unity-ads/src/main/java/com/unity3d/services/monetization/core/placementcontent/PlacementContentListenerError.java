package com.unity3d.services.monetization.core.placementcontent;

public enum PlacementContentListenerError {
    PLACEMENTCONTENT_LISTENER_ERROR,
    PLACEMENTCONTENT_LISTENER_NULL
}
