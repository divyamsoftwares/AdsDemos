package com.unity3d.services.core.webview.bridge;

public interface IWebViewSharedObject {
	String getId();
}
