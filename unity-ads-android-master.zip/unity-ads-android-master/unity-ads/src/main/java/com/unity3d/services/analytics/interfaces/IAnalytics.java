package com.unity3d.services.analytics.interfaces;

public interface IAnalytics {
    void onAddExtras(String extras);
}
