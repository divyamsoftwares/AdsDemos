package com.unity3d.services.core.request;

public enum ResolveHostEvent {
	COMPLETE,
	FAILED
}
