package com.unity3d.services.ads.adunit;

public enum PermissionsEvent {
	PERMISSIONS_RESULT,
	PERMISSIONS_ERROR
}
