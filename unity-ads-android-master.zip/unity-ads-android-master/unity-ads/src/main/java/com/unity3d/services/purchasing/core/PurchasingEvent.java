package com.unity3d.services.purchasing.core;

public enum PurchasingEvent {
    PRODUCTS_RETRIEVED,
    TRANSACTION_COMPLETE,
    TRANSACTION_ERROR
}
