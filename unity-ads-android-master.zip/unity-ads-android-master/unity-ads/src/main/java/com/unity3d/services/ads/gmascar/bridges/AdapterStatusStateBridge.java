package com.unity3d.services.ads.gmascar.bridges;

public class AdapterStatusStateBridge {

	public AdapterStatusStateBridge() {};

	public String getClassName() {
		return "com.google.android.gms.ads.initialization.AdapterStatus$State";
	}

}
