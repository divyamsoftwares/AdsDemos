package com.unity3d.services.ads.token;

public enum TokenEvent {
	TOKEN_ACCESS,
	QUEUE_EMPTY
}
