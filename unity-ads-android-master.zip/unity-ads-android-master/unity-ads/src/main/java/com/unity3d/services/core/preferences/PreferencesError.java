package com.unity3d.services.core.preferences;

public enum PreferencesError {
	COULDNT_GET_VALUE
}
