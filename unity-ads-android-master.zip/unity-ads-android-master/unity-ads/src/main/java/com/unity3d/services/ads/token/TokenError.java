package com.unity3d.services.ads.token;

public enum TokenError {
	JSON_EXCEPTION
}
