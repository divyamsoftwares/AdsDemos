package com.unity3d.services.monetization.core.placementcontent;

public enum PlacementContentEvent {
    CUSTOM
}
