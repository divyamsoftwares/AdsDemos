package com.unity3d.scar.adapter.common.scarads;

public interface IScarLoadListener {
	void onAdLoaded();
}
