# Appodeal Android SDK Demo Project

[![](https://img.shields.io/badge/SDK%20version-Stable%202.10.3-brightgreen)](https://wiki.appodeal.com/en/android/get-started)

[Documentation](https://wiki.appodeal.com/en/android/get-started)

### Data Protection Regulation (GDPR, CCPA)
https://wiki.appodeal.com/en/android/get-started/data-protection/gdpr-and-ccpa

[Example consent code](https://github.com/appodeal/appodeal-android-demo/blob/master/app/src/main/java/com/appodeal/test/SplashActivity.java)
