// Copyright 2018-2021 Twitter, Inc.
// Licensed under the MoPub SDK License Agreement
// https://www.mopub.com/legal/sdk-license-agreement/

package com.mopub.common;

public enum AdFormat {
    BANNER,
    INTERSTITIAL,
    NATIVE,
    REWARDED_AD,
}
