One line summary of the issue here

- [ ] I am submitting a bug report for existing functionality
- [ ] I visited https://developers.mopub.com/ and found no answer
- [ ] I checked https://twittercommunity.com/c/advertiser-api/mopub to make sure that this issue has not already been filed
- [ ] I checked to make sure that this issue has not already been filed

#### MoPub SDK Version:

#### Android Studio Version:

#### Gradle Version:

#### Device model and OS Version:

#### Ad Unit IDs used in reproducing the issue:

#### Steps to reproduce the behavior:
Please list all relevant steps to reproduce the observed behavior.

#### Expected behavior:
As concisely as possible, describe the expected behavior.

#### Observed behavior:
As concisely as possible, describe the observed behavior.

#### Evidence:
Device log files, Network log file, etc.
